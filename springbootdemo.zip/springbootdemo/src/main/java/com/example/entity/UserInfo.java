package com.example.entity;

import org.springframework.stereotype.Component;

@Component
public class UserInfo {

	
}
